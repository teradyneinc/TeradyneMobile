###############################################################################
# File name: Read_me.txt
# Created By: The Uniform Server Development Team
# V 1.0 18-8-2011
###############################################################################

 The following files are included for testing and can be safely deleted.

 test.pl      - Perl script
 test.vbs     - VBScript 
 Read_me.txt  - This file

 -------
 test.pl
 -------
 After installing Perl, run this script by typing http://localhost/cgi-bin/test.pl
 into your browser. The script displays a list of environment variables.

 --------
 test.vbs
 --------
 You can use VBScript for CGI pages. Run the example script by typing
 http://localhost/cgi-bin/test.vbs into your browser.
 The script displays a list of environment variables.

------------------------------------ End --------------------------------------

 

