
document.write('<span class=\"sub_menu_header\">MSMTP</span>');

document.write('<div id=\"lcon1\">');
document.write('<ul class=\"lmen1\">');

document.write('<li class=\"p710\"><a href=\"msmtp_detail.html\"  target=\"_top\">MSMTP- Detail</a></li>');

document.write('</ul>');
document.write('</div>');
