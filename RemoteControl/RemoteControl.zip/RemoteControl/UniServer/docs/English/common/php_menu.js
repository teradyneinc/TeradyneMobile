
document.write('<span class=\"sub_menu_header\">PHP</span>');

document.write('<div id=\"lcon1\">');
document.write('<ul class=\"lmen1\">');

document.write('<li class=\"p610\"><a href=\"php_short_open_tags.html\"  target=\"_top\">Short open tags</a></li>');
document.write('<li class=\"p620\"><a href=\"php_pear.html\"  target=\"_top\">PEAR Auto Install</a></li>');
document.write('<li class=\"p630\"><a href=\"php_pear_manual_install.html\"  target=\"_top\">PEAR Manual Install</a></li>');
document.write('<li class=\"p640\"><a href=\"php_apc.html\"  target=\"_top\">PHP - APC</a></li>');

document.write('</ul>');
document.write('</div>');
