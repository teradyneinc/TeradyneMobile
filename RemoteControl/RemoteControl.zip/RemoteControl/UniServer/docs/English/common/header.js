document.write('<table id=\"banner\"><tr><td id=\"td_banner\">');

document.write(' <div id=\"banner_text\">');
document.write(' UniServer 8-Coral');
document.write(' </div>');

document.write('<img src=\"common/images/us_coral_logo.png\" alt=\"The Uniform Server\" />');


document.write('</td></tr></table>');
