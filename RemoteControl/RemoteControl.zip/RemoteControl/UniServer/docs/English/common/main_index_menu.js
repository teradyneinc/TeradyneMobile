
document.write('<div id=\"lcon1\">');
document.write('<ul class=\"lmen1\">');

document.write('<li ><a href=\"index.html\" target=\"_top\">Return Document Home Page</a>   </li>');

document.write('<li ><a href=\"index_main.html\" target=\"_top\">Home <span class="speed_arrow">&raquo;</span>   </a>   </li>');
document.write('<li ><a href=\"#Quick Start\"  target=\"_top\">Quick Start <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#General\"  target=\"_top\">General <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#Apache\"  target=\"_top\">Apache <span class="speed_arrow">&raquo;</span></a></li>');


document.write('<li ><a href=\"#MySQL\"  target=\"_top\">MySQL <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#PHP\"  target=\"_top\">PHP <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#MSMTP\"  target=\"_top\">MSMTP <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#CRON\"  target=\"_top\">Cron <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#DtDNS\"  target=\"_top\">DtDNS <span class="speed_arrow">&raquo;</span></a></li>');


document.write('<li ><a href=\"#Db Backup\"  target=\"_top\">DB Back-up <span class="speed_arrow">&raquo;</span></a></li>');
document.write('<li ><a href=\"#Perl\"  target=\"_top\">Perl <span class="speed_arrow">&raquo;</span></a></li>');

document.write('</ul>');
document.write('</div>');
